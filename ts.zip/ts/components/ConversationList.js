"use strict";
// Copyright 2021 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConversationList = exports.RowType = void 0;
const react_1 = __importStar(require("react"));
const react_virtualized_1 = require("react-virtualized");
const classnames_1 = __importDefault(require("classnames"));
const missingCaseError_1 = require("../util/missingCaseError");
const assert_1 = require("../util/assert");
const Util_1 = require("../types/Util");
const ConversationListItem_1 = require("./conversationList/ConversationListItem");
const ContactListItem_1 = require("./conversationList/ContactListItem");
const ContactCheckbox_1 = require("./conversationList/ContactCheckbox");
const CreateNewGroupButton_1 = require("./conversationList/CreateNewGroupButton");
const StartNewConversation_1 = require("./conversationList/StartNewConversation");
const SearchResultsLoadingFakeHeader_1 = require("./conversationList/SearchResultsLoadingFakeHeader");
const SearchResultsLoadingFakeRow_1 = require("./conversationList/SearchResultsLoadingFakeRow");
var RowType;
(function (RowType) {
    RowType[RowType["ArchiveButton"] = 0] = "ArchiveButton";
    RowType[RowType["Blank"] = 1] = "Blank";
    RowType[RowType["Contact"] = 2] = "Contact";
    RowType[RowType["ContactCheckbox"] = 3] = "ContactCheckbox";
    RowType[RowType["Conversation"] = 4] = "Conversation";
    RowType[RowType["CreateNewGroup"] = 5] = "CreateNewGroup";
    RowType[RowType["Header"] = 6] = "Header";
    RowType[RowType["MessageSearchResult"] = 7] = "MessageSearchResult";
    RowType[RowType["SearchResultsLoadingFakeHeader"] = 8] = "SearchResultsLoadingFakeHeader";
    RowType[RowType["SearchResultsLoadingFakeRow"] = 9] = "SearchResultsLoadingFakeRow";
    RowType[RowType["StartNewConversation"] = 10] = "StartNewConversation";
})(RowType = exports.RowType || (exports.RowType = {}));
const NORMAL_ROW_HEIGHT = 68;
const HEADER_ROW_HEIGHT = 40;
const ConversationList = ({ dimensions, getRow, i18n, onClickArchiveButton, onClickContactCheckbox, onSelectConversation, renderMessageSearchResult, rowCount, scrollBehavior = Util_1.ScrollBehavior.Default, scrollToRowIndex, scrollable = true, shouldRecomputeRowHeights, showChooseGroupMembers, startNewConversationFromPhoneNumber, }) => {
    const listRef = react_1.useRef(null);
    react_1.useEffect(() => {
        const list = listRef.current;
        if (shouldRecomputeRowHeights && list) {
            list.recomputeRowHeights();
        }
    }, [shouldRecomputeRowHeights]);
    const calculateRowHeight = react_1.useCallback(({ index }) => {
        const row = getRow(index);
        if (!row) {
            assert_1.assert(false, `Expected a row at index ${index}`);
            return NORMAL_ROW_HEIGHT;
        }
        switch (row.type) {
            case RowType.Header:
            case RowType.SearchResultsLoadingFakeHeader:
                return HEADER_ROW_HEIGHT;
            default:
                return NORMAL_ROW_HEIGHT;
        }
    }, [getRow]);
    const renderRow = react_1.useCallback(({ key, index, style }) => {
        const row = getRow(index);
        if (!row) {
            assert_1.assert(false, `Expected a row at index ${index}`);
            return react_1.default.createElement("div", { key: key, style: style });
        }
        switch (row.type) {
            case RowType.ArchiveButton:
                return (react_1.default.createElement("button", { key: key, className: "module-conversation-list__item--archive-button", style: style, onClick: onClickArchiveButton, type: "button" },
                    i18n('archivedConversations'),
                    ' ',
                    react_1.default.createElement("span", { className: "module-conversation-list__item--archive-button__archived-count" }, row.archivedConversationsCount)));
            case RowType.Blank:
                return react_1.default.createElement("div", { key: key, style: style });
            case RowType.Contact: {
                const { isClickable = true } = row;
                return (react_1.default.createElement(ContactListItem_1.ContactListItem, Object.assign({}, row.contact, { key: key, style: style, onClick: isClickable ? onSelectConversation : undefined, i18n: i18n })));
            }
            case RowType.ContactCheckbox:
                return (react_1.default.createElement(ContactCheckbox_1.ContactCheckbox, Object.assign({}, row.contact, { isChecked: row.isChecked, disabledReason: row.disabledReason, key: key, style: style, onClick: onClickContactCheckbox, i18n: i18n })));
            case RowType.Conversation:
                return (react_1.default.createElement(ConversationListItem_1.ConversationListItem, Object.assign({}, row.conversation, { key: key, style: style, onClick: onSelectConversation, i18n: i18n })));
            case RowType.CreateNewGroup:
                return (react_1.default.createElement(CreateNewGroupButton_1.CreateNewGroupButton, { i18n: i18n, key: key, onClick: showChooseGroupMembers, style: style }));
            case RowType.Header:
                return (react_1.default.createElement("div", { className: "module-conversation-list__item--header", key: key, style: style }, i18n(row.i18nKey)));
            case RowType.MessageSearchResult:
                return (react_1.default.createElement(react_1.default.Fragment, { key: key }, renderMessageSearchResult(row.messageId, style)));
            case RowType.SearchResultsLoadingFakeHeader:
                return (react_1.default.createElement(SearchResultsLoadingFakeHeader_1.SearchResultsLoadingFakeHeader, { key: key, style: style }));
            case RowType.SearchResultsLoadingFakeRow:
                return (react_1.default.createElement(SearchResultsLoadingFakeRow_1.SearchResultsLoadingFakeRow, { key: key, style: style }));
            case RowType.StartNewConversation:
                return (react_1.default.createElement(StartNewConversation_1.StartNewConversation, { i18n: i18n, key: key, phoneNumber: row.phoneNumber, onClick: () => {
                        startNewConversationFromPhoneNumber(row.phoneNumber);
                    }, style: style }));
            default:
                throw missingCaseError_1.missingCaseError(row);
        }
    }, [
        getRow,
        i18n,
        onClickArchiveButton,
        onClickContactCheckbox,
        onSelectConversation,
        renderMessageSearchResult,
        showChooseGroupMembers,
        startNewConversationFromPhoneNumber,
    ]);
    // Though `width` and `height` are required properties, we want to be careful in case
    //   the caller sends bogus data. Notably, react-measure's types seem to be inaccurate.
    const { width = 0, height = 0 } = dimensions || {};
    if (!width || !height) {
        return null;
    }
    return (react_1.default.createElement(react_virtualized_1.List, { className: classnames_1.default('module-conversation-list', `module-conversation-list--scroll-behavior-${scrollBehavior}`), height: height, ref: listRef, rowCount: rowCount, rowHeight: calculateRowHeight, rowRenderer: renderRow, scrollToIndex: scrollToRowIndex, style: { overflow: scrollable ? 'auto' : 'hidden' }, tabIndex: -1, width: width }));
};
exports.ConversationList = ConversationList;
