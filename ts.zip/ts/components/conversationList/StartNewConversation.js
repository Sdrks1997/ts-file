"use strict";
// Copyright 2019-2021 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.StartNewConversation = void 0;
const react_1 = __importDefault(require("react"));
const BaseConversationListItem_1 = require("./BaseConversationListItem");
const TEXT_CLASS_NAME = `${BaseConversationListItem_1.MESSAGE_TEXT_CLASS_NAME}__start-new-conversation`;
exports.StartNewConversation = react_1.default.memo(({ i18n, onClick, phoneNumber, style }) => {
    const messageText = (react_1.default.createElement("div", { className: TEXT_CLASS_NAME }, i18n('startConversation')));
    return (react_1.default.createElement(BaseConversationListItem_1.BaseConversationListItem, { acceptedMessageRequest: false, color: "steel", conversationType: "direct", headerName: phoneNumber, i18n: i18n, isMe: false, isSelected: false, messageText: messageText, onClick: onClick, phoneNumber: phoneNumber, sharedGroupNames: [], style: style, title: phoneNumber }));
});
