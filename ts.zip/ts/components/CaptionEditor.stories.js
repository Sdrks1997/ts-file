"use strict";
// Copyright 2020 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const React = __importStar(require("react"));
const react_1 = require("@storybook/react");
const addon_knobs_1 = require("@storybook/addon-knobs");
const addon_actions_1 = require("@storybook/addon-actions");
const CaptionEditor_1 = require("./CaptionEditor");
const MIME_1 = require("../types/MIME");
const i18n_1 = require("../../js/modules/i18n");
const messages_json_1 = __importDefault(require("../../_locales/en/messages.json"));
const i18n = i18n_1.setup('en', messages_json_1.default);
const stories = react_1.storiesOf('Components/Caption Editor', module);
const createProps = (overrideProps = {}) => ({
    attachment: Object.assign({ contentType: MIME_1.IMAGE_JPEG, fileName: '', url: '' }, overrideProps.attachment),
    caption: addon_knobs_1.text('caption', overrideProps.caption || ''),
    close: addon_actions_1.action('close'),
    i18n,
    onSave: addon_actions_1.action('onSave'),
    url: addon_knobs_1.text('url', overrideProps.url || ''),
});
stories.add('Image', () => {
    const props = createProps({
        url: '/fixtures/tina-rolf-269345-unsplash.jpg',
    });
    return React.createElement(CaptionEditor_1.CaptionEditor, Object.assign({}, props));
});
stories.add('Image with Caption', () => {
    const props = createProps({
        caption: 'This is the user-provided caption. We show it overlaid on the image. If it is really long, then it wraps, but it does not get too close to the edges of the image.',
        url: '/fixtures/tina-rolf-269345-unsplash.jpg',
    });
    return React.createElement(CaptionEditor_1.CaptionEditor, Object.assign({}, props));
});
stories.add('Video', () => {
    const props = createProps({
        attachment: {
            contentType: MIME_1.VIDEO_MP4,
            fileName: 'pixabay-Soap-Bubble-7141.mp4',
            url: '/fixtures/pixabay-Soap-Bubble-7141.mp4',
        },
        url: '/fixtures/pixabay-Soap-Bubble-7141.mp4',
    });
    return React.createElement(CaptionEditor_1.CaptionEditor, Object.assign({}, props));
});
stories.add('Video with Caption', () => {
    const props = createProps({
        attachment: {
            contentType: MIME_1.VIDEO_MP4,
            fileName: 'pixabay-Soap-Bubble-7141.mp4',
            url: '/fixtures/pixabay-Soap-Bubble-7141.mp4',
        },
        caption: 'This is the user-provided caption. We show it overlaid on the image. If it is really long, then it wraps, but it does not get too close to the edges of the image.',
        url: '/fixtures/pixabay-Soap-Bubble-7141.mp4',
    });
    return React.createElement(CaptionEditor_1.CaptionEditor, Object.assign({}, props));
});
stories.add('Unsupported Attachment Type', () => {
    const props = createProps({
        attachment: {
            contentType: MIME_1.AUDIO_MP3,
            fileName: 'incompetech-com-Agnus-Dei-X.mp3',
            url: '/fixtures/incompetech-com-Agnus-Dei-X.mp3',
        },
        url: '/fixtures/incompetech-com-Agnus-Dei-X.mp3',
    });
    return React.createElement(CaptionEditor_1.CaptionEditor, Object.assign({}, props));
});
