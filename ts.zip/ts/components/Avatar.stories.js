"use strict";
// Copyright 2020-2021 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const React = __importStar(require("react"));
const lodash_1 = require("lodash");
const react_1 = require("@storybook/react");
const addon_knobs_1 = require("@storybook/addon-knobs");
const addon_actions_1 = require("@storybook/addon-actions");
const Avatar_1 = require("./Avatar");
const i18n_1 = require("../../js/modules/i18n");
const messages_json_1 = __importDefault(require("../../_locales/en/messages.json"));
const Colors_1 = require("../types/Colors");
const i18n = i18n_1.setup('en', messages_json_1.default);
const story = react_1.storiesOf('Components/Avatar', module);
const colorMap = Colors_1.AvatarColors.reduce((m, color) => (Object.assign(Object.assign({}, m), { [color]: color })), {});
const conversationTypeMap = {
    direct: 'direct',
    group: 'group',
};
const createProps = (overrideProps = {}) => ({
    acceptedMessageRequest: lodash_1.isBoolean(overrideProps.acceptedMessageRequest)
        ? overrideProps.acceptedMessageRequest
        : true,
    avatarPath: addon_knobs_1.text('avatarPath', overrideProps.avatarPath || ''),
    blur: overrideProps.blur,
    color: addon_knobs_1.select('color', colorMap, overrideProps.color || 'blue'),
    conversationType: addon_knobs_1.select('conversationType', conversationTypeMap, overrideProps.conversationType || 'direct'),
    i18n,
    isMe: false,
    loading: addon_knobs_1.boolean('loading', overrideProps.loading || false),
    name: addon_knobs_1.text('name', overrideProps.name || ''),
    noteToSelf: addon_knobs_1.boolean('noteToSelf', overrideProps.noteToSelf || false),
    onClick: addon_actions_1.action('onClick'),
    phoneNumber: addon_knobs_1.text('phoneNumber', overrideProps.phoneNumber || ''),
    sharedGroupNames: [],
    size: 80,
    title: overrideProps.title || '',
});
const sizes = [112, 96, 80, 52, 32, 28];
story.add('Avatar', () => {
    const props = createProps({
        avatarPath: '/fixtures/giphy-GVNvOUpeYmI7e.gif',
    });
    return sizes.map(size => React.createElement(Avatar_1.Avatar, Object.assign({ key: size }, props, { size: size })));
});
story.add('Wide image', () => {
    const props = createProps({
        avatarPath: '/fixtures/wide.jpg',
    });
    return sizes.map(size => React.createElement(Avatar_1.Avatar, Object.assign({ key: size }, props, { size: size })));
});
story.add('One-word Name', () => {
    const props = createProps({
        title: 'John',
    });
    return sizes.map(size => React.createElement(Avatar_1.Avatar, Object.assign({ key: size }, props, { size: size })));
});
story.add('Two-word Name', () => {
    const props = createProps({
        title: 'John Smith',
    });
    return sizes.map(size => React.createElement(Avatar_1.Avatar, Object.assign({ key: size }, props, { size: size })));
});
story.add('Wide initials', () => {
    const props = createProps({
        title: 'Walter White',
    });
    return sizes.map(size => React.createElement(Avatar_1.Avatar, Object.assign({ key: size }, props, { size: size })));
});
story.add('Three-word name', () => {
    const props = createProps({
        title: 'Walter H. White',
    });
    return sizes.map(size => React.createElement(Avatar_1.Avatar, Object.assign({ key: size }, props, { size: size })));
});
story.add('Note to Self', () => {
    const props = createProps({
        noteToSelf: true,
    });
    return sizes.map(size => React.createElement(Avatar_1.Avatar, Object.assign({ key: size }, props, { size: size })));
});
story.add('Contact Icon', () => {
    const props = createProps();
    return sizes.map(size => React.createElement(Avatar_1.Avatar, Object.assign({ key: size }, props, { size: size })));
});
story.add('Group Icon', () => {
    const props = createProps({
        conversationType: 'group',
    });
    return sizes.map(size => React.createElement(Avatar_1.Avatar, Object.assign({ key: size }, props, { size: size })));
});
story.add('Colors', () => {
    const props = createProps();
    return Colors_1.AvatarColors.map(color => (React.createElement(Avatar_1.Avatar, Object.assign({ key: color }, props, { color: color }))));
});
story.add('Broken Color', () => {
    const props = createProps({
        color: 'nope',
    });
    return sizes.map(size => React.createElement(Avatar_1.Avatar, Object.assign({ key: size }, props, { size: size })));
});
story.add('Broken Avatar', () => {
    const props = createProps({
        avatarPath: 'badimage.png',
    });
    return sizes.map(size => React.createElement(Avatar_1.Avatar, Object.assign({ key: size }, props, { size: size })));
});
story.add('Broken Avatar for Group', () => {
    const props = createProps({
        avatarPath: 'badimage.png',
        conversationType: 'group',
    });
    return sizes.map(size => React.createElement(Avatar_1.Avatar, Object.assign({ key: size }, props, { size: size })));
});
story.add('Loading', () => {
    const props = createProps({
        loading: true,
    });
    return sizes.map(size => React.createElement(Avatar_1.Avatar, Object.assign({ key: size }, props, { size: size })));
});
story.add('Blurred based on props', () => {
    const props = createProps({
        acceptedMessageRequest: false,
        avatarPath: '/fixtures/kitten-3-64-64.jpg',
    });
    return sizes.map(size => React.createElement(Avatar_1.Avatar, Object.assign({ key: size }, props, { size: size })));
});
story.add('Force-blurred', () => {
    const props = createProps({
        avatarPath: '/fixtures/kitten-3-64-64.jpg',
        blur: Avatar_1.AvatarBlur.BlurPicture,
    });
    return sizes.map(size => React.createElement(Avatar_1.Avatar, Object.assign({ key: size }, props, { size: size })));
});
story.add('Blurred with "click to view"', () => {
    const props = createProps({
        avatarPath: '/fixtures/kitten-3-64-64.jpg',
        blur: Avatar_1.AvatarBlur.BlurPictureWithClickToView,
    });
    return React.createElement(Avatar_1.Avatar, Object.assign({}, props, { size: 112 }));
});
