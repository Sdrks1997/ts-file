"use strict";
// Copyright 2020 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const React = __importStar(require("react"));
const addon_actions_1 = require("@storybook/addon-actions");
const react_1 = require("@storybook/react");
const AttachmentList_1 = require("./AttachmentList");
const MIME_1 = require("../../types/MIME");
const i18n_1 = require("../../../js/modules/i18n");
const messages_json_1 = __importDefault(require("../../../_locales/en/messages.json"));
const i18n = i18n_1.setup('en', messages_json_1.default);
const story = react_1.storiesOf('Components/Conversation/AttachmentList', module);
const createProps = (overrideProps = {}) => ({
    attachments: overrideProps.attachments || [],
    i18n,
    onAddAttachment: addon_actions_1.action('onAddAttachment'),
    onClickAttachment: addon_actions_1.action('onClickAttachment'),
    onClose: addon_actions_1.action('onClose'),
    onCloseAttachment: addon_actions_1.action('onCloseAttachment'),
});
story.add('One File', () => {
    const props = createProps({
        attachments: [
            {
                contentType: MIME_1.IMAGE_JPEG,
                fileName: 'tina-rolf-269345-unsplash.jpg',
                url: '/fixtures/tina-rolf-269345-unsplash.jpg',
            },
        ],
    });
    return React.createElement(AttachmentList_1.AttachmentList, Object.assign({}, props));
});
story.add('Multiple Visual Attachments', () => {
    const props = createProps({
        attachments: [
            {
                contentType: MIME_1.IMAGE_JPEG,
                fileName: 'tina-rolf-269345-unsplash.jpg',
                url: '/fixtures/tina-rolf-269345-unsplash.jpg',
            },
            {
                contentType: MIME_1.VIDEO_MP4,
                fileName: 'pixabay-Soap-Bubble-7141.mp4',
                url: '/fixtures/pixabay-Soap-Bubble-7141.mp4',
                screenshot: {
                    height: 112,
                    width: 112,
                    url: '/fixtures/kitten-4-112-112.jpg',
                    contentType: MIME_1.IMAGE_JPEG,
                    path: 'originalpath',
                },
            },
            {
                contentType: MIME_1.IMAGE_GIF,
                fileName: 'giphy-GVNv0UpeYm17e',
                url: '/fixtures/giphy-GVNvOUpeYmI7e.gif',
            },
        ],
    });
    return React.createElement(AttachmentList_1.AttachmentList, Object.assign({}, props));
});
story.add('Multiple with Non-Visual Types', () => {
    const props = createProps({
        attachments: [
            {
                contentType: MIME_1.IMAGE_JPEG,
                fileName: 'tina-rolf-269345-unsplash.jpg',
                url: '/fixtures/tina-rolf-269345-unsplash.jpg',
            },
            {
                contentType: 'text/plain',
                fileName: 'lorem-ipsum.txt',
                url: '/fixtures/lorem-ipsum.txt',
            },
            {
                contentType: MIME_1.AUDIO_MP3,
                fileName: 'incompetech-com-Agnus-Dei-X.mp3',
                url: '/fixtures/incompetech-com-Agnus-Dei-X.mp3',
            },
            {
                contentType: MIME_1.VIDEO_MP4,
                fileName: 'pixabay-Soap-Bubble-7141.mp4',
                url: '/fixtures/pixabay-Soap-Bubble-7141.mp4',
                screenshot: {
                    height: 112,
                    width: 112,
                    url: '/fixtures/kitten-4-112-112.jpg',
                    contentType: MIME_1.IMAGE_JPEG,
                    path: 'originalpath',
                },
            },
            {
                contentType: MIME_1.IMAGE_GIF,
                fileName: 'giphy-GVNv0UpeYm17e',
                url: '/fixtures/giphy-GVNvOUpeYmI7e.gif',
            },
        ],
    });
    return React.createElement(AttachmentList_1.AttachmentList, Object.assign({}, props));
});
story.add('Empty List', () => {
    const props = createProps();
    return React.createElement(AttachmentList_1.AttachmentList, Object.assign({}, props));
});
