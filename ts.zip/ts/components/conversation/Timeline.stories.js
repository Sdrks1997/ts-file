"use strict";
// Copyright 2020-2021 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const React = __importStar(require("react"));
const moment = __importStar(require("moment"));
const lodash_1 = require("lodash");
const uuid_1 = require("uuid");
const react_1 = require("@storybook/react");
const addon_knobs_1 = require("@storybook/addon-knobs");
const addon_actions_1 = require("@storybook/addon-actions");
const i18n_1 = require("../../../js/modules/i18n");
const messages_json_1 = __importDefault(require("../../../_locales/en/messages.json"));
const Timeline_1 = require("./Timeline");
const TimelineItem_1 = require("./TimelineItem");
const ConversationHero_1 = require("./ConversationHero");
const getDefaultConversation_1 = require("../../test-both/helpers/getDefaultConversation");
const LastSeenIndicator_1 = require("./LastSeenIndicator");
const TimelineLoadingRow_1 = require("./TimelineLoadingRow");
const TypingBubble_1 = require("./TypingBubble");
const contactSpoofing_1 = require("../../util/contactSpoofing");
const i18n = i18n_1.setup('en', messages_json_1.default);
const story = react_1.storiesOf('Components/Conversation/Timeline', module);
// eslint-disable-next-line
const noop = () => { };
Object.assign(window, {
    registerForActive: noop,
    unregisterForActive: noop,
});
const items = {
    'id-1': {
        type: 'message',
        data: {
            author: getDefaultConversation_1.getDefaultConversation({
                phoneNumber: '(202) 555-2001',
                color: 'forest',
            }),
            canDeleteForEveryone: false,
            canDownload: true,
            canReply: true,
            conversationColor: 'forest',
            conversationId: 'conversation-id',
            conversationType: 'group',
            direction: 'incoming',
            id: 'id-1',
            isBlocked: false,
            isMessageRequestAccepted: true,
            previews: [],
            text: '🔥',
            timestamp: Date.now(),
        },
    },
    'id-2': {
        type: 'message',
        data: {
            author: getDefaultConversation_1.getDefaultConversation({ color: 'forest' }),
            canDeleteForEveryone: false,
            canDownload: true,
            canReply: true,
            conversationColor: 'forest',
            conversationId: 'conversation-id',
            conversationType: 'group',
            direction: 'incoming',
            id: 'id-2',
            isBlocked: false,
            isMessageRequestAccepted: true,
            previews: [],
            text: 'Hello there from the new world! http://somewhere.com',
            timestamp: Date.now(),
        },
    },
    'id-2.5': {
        type: 'unsupportedMessage',
        data: {
            id: 'id-2.5',
            canProcessNow: false,
            contact: {
                id: '061d3783-5736-4145-b1a2-6b6cf1156393',
                isMe: false,
                phoneNumber: '(202) 555-1000',
                profileName: 'Mr. Pig',
                title: 'Mr. Pig',
            },
        },
    },
    'id-3': {
        type: 'message',
        data: {
            author: getDefaultConversation_1.getDefaultConversation({ color: 'crimson' }),
            canDeleteForEveryone: false,
            canDownload: true,
            canReply: true,
            conversationColor: 'crimson',
            conversationId: 'conversation-id',
            conversationType: 'group',
            direction: 'incoming',
            id: 'id-3',
            isBlocked: false,
            isMessageRequestAccepted: true,
            previews: [],
            text: 'Hello there from the new world!',
            timestamp: Date.now(),
        },
    },
    'id-4': {
        type: 'timerNotification',
        data: {
            disabled: false,
            expireTimer: moment.duration(2, 'hours').asSeconds(),
            title: "It's Me",
            type: 'fromMe',
        },
    },
    'id-5': {
        type: 'timerNotification',
        data: {
            disabled: false,
            expireTimer: moment.duration(2, 'hours').asSeconds(),
            phoneNumber: '(202) 555-0000',
            title: '(202) 555-0000',
            type: 'fromOther',
        },
    },
    'id-6': {
        type: 'safetyNumberNotification',
        data: {
            contact: {
                id: '+1202555000',
                phoneNumber: '(202) 555-0000',
                profileName: 'Mr. Fire',
                title: 'Mr. Fire',
            },
            isGroup: true,
        },
    },
    'id-7': {
        type: 'verificationNotification',
        data: {
            contact: {
                name: 'Mrs. Ice',
                phoneNumber: '(202) 555-0001',
                title: 'Mrs. Ice',
            },
            isLocal: true,
            type: 'markVerified',
        },
    },
    'id-8': {
        type: 'groupNotification',
        data: {
            changes: [
                {
                    type: 'name',
                    newName: 'Squirrels and their uses',
                },
                {
                    type: 'add',
                    contacts: [
                        {
                            phoneNumber: '(202) 555-0002',
                            profileName: 'Mr. Fire',
                            title: 'Mr. Fire',
                        },
                        {
                            phoneNumber: '(202) 555-0003',
                            profileName: 'Ms. Water',
                            title: 'Ms. Water',
                        },
                    ],
                },
            ],
            from: {
                phoneNumber: '(202) 555-0001',
                name: 'Mrs. Ice',
                title: 'Mrs. Ice',
                isMe: false,
            },
        },
    },
    'id-9': {
        type: 'resetSessionNotification',
        data: null,
    },
    'id-10': {
        type: 'message',
        data: {
            author: getDefaultConversation_1.getDefaultConversation({ color: 'plum' }),
            canDeleteForEveryone: false,
            canDownload: true,
            canReply: true,
            conversationColor: 'plum',
            conversationId: 'conversation-id',
            conversationType: 'group',
            direction: 'outgoing',
            id: 'id-6',
            isBlocked: false,
            isMessageRequestAccepted: true,
            previews: [],
            status: 'sent',
            text: '🔥',
            timestamp: Date.now(),
        },
    },
    'id-11': {
        type: 'message',
        data: {
            author: getDefaultConversation_1.getDefaultConversation({ color: 'plum' }),
            canDeleteForEveryone: false,
            canDownload: true,
            canReply: true,
            conversationColor: 'crimson',
            conversationId: 'conversation-id',
            conversationType: 'group',
            direction: 'outgoing',
            id: 'id-7',
            isBlocked: false,
            isMessageRequestAccepted: true,
            previews: [],
            status: 'read',
            text: 'Hello there from the new world! http://somewhere.com',
            timestamp: Date.now(),
        },
    },
    'id-12': {
        type: 'message',
        data: {
            author: getDefaultConversation_1.getDefaultConversation({ color: 'crimson' }),
            canDeleteForEveryone: false,
            canDownload: true,
            canReply: true,
            conversationColor: 'crimson',
            conversationId: 'conversation-id',
            conversationType: 'group',
            direction: 'outgoing',
            id: 'id-8',
            isBlocked: false,
            isMessageRequestAccepted: true,
            previews: [],
            status: 'sent',
            text: 'Hello there from the new world! 🔥',
            timestamp: Date.now(),
        },
    },
    'id-13': {
        type: 'message',
        data: {
            author: getDefaultConversation_1.getDefaultConversation({ color: 'blue' }),
            canDeleteForEveryone: false,
            canDownload: true,
            canReply: true,
            conversationColor: 'crimson',
            conversationId: 'conversation-id',
            conversationType: 'group',
            direction: 'outgoing',
            id: 'id-9',
            isBlocked: false,
            isMessageRequestAccepted: true,
            previews: [],
            status: 'sent',
            text: 'Hello there from the new world! And this is multiple lines of text. Lines and lines and lines.',
            timestamp: Date.now(),
        },
    },
    'id-14': {
        type: 'message',
        data: {
            author: getDefaultConversation_1.getDefaultConversation({ color: 'crimson' }),
            canDeleteForEveryone: false,
            canDownload: true,
            canReply: true,
            conversationColor: 'crimson',
            conversationId: 'conversation-id',
            conversationType: 'group',
            direction: 'outgoing',
            id: 'id-10',
            isBlocked: false,
            isMessageRequestAccepted: true,
            previews: [],
            status: 'read',
            text: 'Hello there from the new world! And this is multiple lines of text. Lines and lines and lines.',
            timestamp: Date.now(),
        },
    },
    'id-15': {
        type: 'linkNotification',
        data: null,
    },
};
const actions = () => ({
    acknowledgeGroupMemberNameCollisions: addon_actions_1.action('acknowledgeGroupMemberNameCollisions'),
    checkForAccount: addon_actions_1.action('checkForAccount'),
    clearChangedMessages: addon_actions_1.action('clearChangedMessages'),
    clearInvitedConversationsForNewlyCreatedGroup: addon_actions_1.action('clearInvitedConversationsForNewlyCreatedGroup'),
    setLoadCountdownStart: addon_actions_1.action('setLoadCountdownStart'),
    setIsNearBottom: addon_actions_1.action('setIsNearBottom'),
    loadAndScroll: addon_actions_1.action('loadAndScroll'),
    loadOlderMessages: addon_actions_1.action('loadOlderMessages'),
    loadNewerMessages: addon_actions_1.action('loadNewerMessages'),
    loadNewestMessages: addon_actions_1.action('loadNewestMessages'),
    markMessageRead: addon_actions_1.action('markMessageRead'),
    selectMessage: addon_actions_1.action('selectMessage'),
    clearSelectedMessage: addon_actions_1.action('clearSelectedMessage'),
    updateSharedGroups: addon_actions_1.action('updateSharedGroups'),
    reactToMessage: addon_actions_1.action('reactToMessage'),
    replyToMessage: addon_actions_1.action('replyToMessage'),
    retrySend: addon_actions_1.action('retrySend'),
    deleteMessage: addon_actions_1.action('deleteMessage'),
    deleteMessageForEveryone: addon_actions_1.action('deleteMessageForEveryone'),
    showMessageDetail: addon_actions_1.action('showMessageDetail'),
    openConversation: addon_actions_1.action('openConversation'),
    showContactDetail: addon_actions_1.action('showContactDetail'),
    showContactModal: addon_actions_1.action('showContactModal'),
    kickOffAttachmentDownload: addon_actions_1.action('kickOffAttachmentDownload'),
    markAttachmentAsCorrupted: addon_actions_1.action('markAttachmentAsCorrupted'),
    showVisualAttachment: addon_actions_1.action('showVisualAttachment'),
    downloadAttachment: addon_actions_1.action('downloadAttachment'),
    displayTapToViewMessage: addon_actions_1.action('displayTapToViewMessage'),
    doubleCheckMissingQuoteReference: addon_actions_1.action('doubleCheckMissingQuoteReference'),
    onHeightChange: addon_actions_1.action('onHeightChange'),
    openLink: addon_actions_1.action('openLink'),
    scrollToQuotedMessage: addon_actions_1.action('scrollToQuotedMessage'),
    showExpiredIncomingTapToViewToast: addon_actions_1.action('showExpiredIncomingTapToViewToast'),
    showExpiredOutgoingTapToViewToast: addon_actions_1.action('showExpiredOutgoingTapToViewToast'),
    showForwardMessageModal: addon_actions_1.action('showForwardMessageModal'),
    showIdentity: addon_actions_1.action('showIdentity'),
    downloadNewVersion: addon_actions_1.action('downloadNewVersion'),
    messageSizeChanged: addon_actions_1.action('messageSizeChanged'),
    startCallingLobby: addon_actions_1.action('startCallingLobby'),
    returnToActiveCall: addon_actions_1.action('returnToActiveCall'),
    contactSupport: addon_actions_1.action('contactSupport'),
    closeContactSpoofingReview: addon_actions_1.action('closeContactSpoofingReview'),
    reviewGroupMemberNameCollision: addon_actions_1.action('reviewGroupMemberNameCollision'),
    reviewMessageRequestNameCollision: addon_actions_1.action('reviewMessageRequestNameCollision'),
    onBlock: addon_actions_1.action('onBlock'),
    onBlockAndReportSpam: addon_actions_1.action('onBlockAndReportSpam'),
    onDelete: addon_actions_1.action('onDelete'),
    onUnblock: addon_actions_1.action('onUnblock'),
    removeMember: addon_actions_1.action('removeMember'),
    unblurAvatar: addon_actions_1.action('unblurAvatar'),
});
const renderItem = (id) => (React.createElement(TimelineItem_1.TimelineItem, Object.assign({ id: "", isSelected: false, renderEmojiPicker: () => React.createElement("div", null), item: items[id], i18n: i18n, interactionMode: "keyboard", conversationId: "", conversationAccepted: true, renderContact: () => '*ContactName*', renderUniversalTimerNotification: () => (React.createElement("div", null, "*UniversalTimerNotification*")), renderAudioAttachment: () => React.createElement("div", null, "*AudioAttachment*") }, actions())));
const renderLastSeenIndicator = () => (React.createElement(LastSeenIndicator_1.LastSeenIndicator, { count: 2, i18n: i18n }));
const getAbout = () => addon_knobs_1.text('about', '👍 Free to chat');
const getTitle = () => addon_knobs_1.text('name', 'Cayce Bollard');
const getName = () => addon_knobs_1.text('name', 'Cayce Bollard');
const getProfileName = () => addon_knobs_1.text('profileName', 'Cayce Bollard (profile)');
const getAvatarPath = () => addon_knobs_1.text('avatarPath', '/fixtures/kitten-4-112-112.jpg');
const getPhoneNumber = () => addon_knobs_1.text('phoneNumber', '+1 (808) 555-1234');
const renderHeroRow = () => (React.createElement(ConversationHero_1.ConversationHero, { about: getAbout(), acceptedMessageRequest: true, i18n: i18n, isMe: false, title: getTitle(), avatarPath: getAvatarPath(), name: getName(), profileName: getProfileName(), phoneNumber: getPhoneNumber(), conversationType: "direct", sharedGroupNames: ['NYC Rock Climbers', 'Dinner Party'], unblurAvatar: addon_actions_1.action('unblurAvatar'), updateSharedGroups: noop }));
const renderLoadingRow = () => React.createElement(TimelineLoadingRow_1.TimelineLoadingRow, { state: "loading" });
const renderTypingBubble = () => (React.createElement(TypingBubble_1.TypingBubble, { acceptedMessageRequest: true, color: "crimson", conversationType: "direct", phoneNumber: "+18005552222", i18n: i18n, isMe: false, title: "title", sharedGroupNames: [] }));
const createProps = (overrideProps = {}) => (Object.assign({ i18n, haveNewest: addon_knobs_1.boolean('haveNewest', overrideProps.haveNewest !== false), haveOldest: addon_knobs_1.boolean('haveOldest', overrideProps.haveOldest !== false), isIncomingMessageRequest: addon_knobs_1.boolean('isIncomingMessageRequest', overrideProps.isIncomingMessageRequest === true), isLoadingMessages: addon_knobs_1.boolean('isLoadingMessages', overrideProps.isLoadingMessages === false), items: overrideProps.items || Object.keys(items), resetCounter: 0, scrollToIndex: overrideProps.scrollToIndex, scrollToIndexCounter: 0, totalUnread: addon_knobs_1.number('totalUnread', overrideProps.totalUnread || 0), oldestUnreadIndex: addon_knobs_1.number('oldestUnreadIndex', overrideProps.oldestUnreadIndex || 0) ||
        undefined, invitedContactsForNewlyCreatedGroup: overrideProps.invitedContactsForNewlyCreatedGroup || [], warning: overrideProps.warning, id: uuid_1.v4(), renderItem,
    renderLastSeenIndicator,
    renderHeroRow,
    renderLoadingRow,
    renderTypingBubble, typingContact: addon_knobs_1.boolean('typingContact', lodash_1.isBoolean(overrideProps.typingContact) ? overrideProps.typingContact : false) }, actions()));
story.add('Oldest and Newest', () => {
    const props = createProps();
    return React.createElement(Timeline_1.Timeline, Object.assign({}, props));
});
story.add('With active message request', () => {
    const props = createProps({
        isIncomingMessageRequest: true,
    });
    return React.createElement(Timeline_1.Timeline, Object.assign({}, props));
});
story.add('Without Newest Message', () => {
    const props = createProps({
        haveNewest: false,
    });
    return React.createElement(Timeline_1.Timeline, Object.assign({}, props));
});
story.add('Without newest message, active message request', () => {
    const props = createProps({
        haveOldest: false,
        isIncomingMessageRequest: true,
    });
    return React.createElement(Timeline_1.Timeline, Object.assign({}, props));
});
story.add('Without Oldest Message', () => {
    const props = createProps({
        haveOldest: false,
        scrollToIndex: -1,
    });
    return React.createElement(Timeline_1.Timeline, Object.assign({}, props));
});
story.add('Empty (just hero)', () => {
    const props = createProps({
        items: [],
    });
    return React.createElement(Timeline_1.Timeline, Object.assign({}, props));
});
story.add('Last Seen', () => {
    const props = createProps({
        oldestUnreadIndex: 13,
        totalUnread: 2,
    });
    return React.createElement(Timeline_1.Timeline, Object.assign({}, props));
});
story.add('Target Index to Top', () => {
    const props = createProps({
        scrollToIndex: 0,
    });
    return React.createElement(Timeline_1.Timeline, Object.assign({}, props));
});
story.add('Typing Indicator', () => {
    const props = createProps({
        typingContact: true,
    });
    return React.createElement(Timeline_1.Timeline, Object.assign({}, props));
});
story.add('With invited contacts for a newly-created group', () => {
    const props = createProps({
        invitedContactsForNewlyCreatedGroup: [
            getDefaultConversation_1.getDefaultConversation({
                id: 'abc123',
                title: 'John Bon Bon Jovi',
            }),
            getDefaultConversation_1.getDefaultConversation({
                id: 'def456',
                title: 'Bon John Bon Jovi',
            }),
        ],
    });
    return React.createElement(Timeline_1.Timeline, Object.assign({}, props));
});
story.add('With "same name in direct conversation" warning', () => {
    const props = createProps({
        warning: {
            type: contactSpoofing_1.ContactSpoofingType.DirectConversationWithSameTitle,
            safeConversation: getDefaultConversation_1.getDefaultConversation(),
        },
        items: [],
    });
    return React.createElement(Timeline_1.Timeline, Object.assign({}, props));
});
story.add('With "same name in group conversation" warning', () => {
    const props = createProps({
        warning: {
            type: contactSpoofing_1.ContactSpoofingType.MultipleGroupMembersWithSameTitle,
            acknowledgedGroupNameCollisions: {},
            groupNameCollisions: {
                Alice: lodash_1.times(2, () => uuid_1.v4()),
                Bob: lodash_1.times(3, () => uuid_1.v4()),
            },
        },
        items: [],
    });
    return React.createElement(Timeline_1.Timeline, Object.assign({}, props));
});
