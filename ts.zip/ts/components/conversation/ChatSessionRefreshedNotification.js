"use strict";
// Copyright 2021 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChatSessionRefreshedNotification = void 0;
const react_1 = __importStar(require("react"));
const ChatSessionRefreshedDialog_1 = require("./ChatSessionRefreshedDialog");
function ChatSessionRefreshedNotification(props) {
    const { contactSupport, i18n } = props;
    const [isDialogOpen, setIsDialogOpen] = react_1.useState(false);
    const openDialog = react_1.useCallback(() => {
        setIsDialogOpen(true);
    }, [setIsDialogOpen]);
    const closeDialog = react_1.useCallback(() => {
        setIsDialogOpen(false);
    }, [setIsDialogOpen]);
    const wrappedContactSupport = react_1.useCallback(() => {
        setIsDialogOpen(false);
        contactSupport();
    }, [contactSupport, setIsDialogOpen]);
    return (react_1.default.createElement("div", { className: "module-chat-session-refreshed-notification" },
        react_1.default.createElement("div", { className: "module-chat-session-refreshed-notification__first-line" },
            react_1.default.createElement("span", { className: "module-chat-session-refreshed-notification__icon" }),
            i18n('ChatRefresh--notification')),
        react_1.default.createElement("button", { type: "button", onClick: openDialog, className: "module-chat-session-refreshed-notification__button" }, i18n('ChatRefresh--learnMore')),
        isDialogOpen ? (react_1.default.createElement(ChatSessionRefreshedDialog_1.ChatSessionRefreshedDialog, { onClose: closeDialog, contactSupport: wrappedContactSupport, i18n: i18n })) : null));
}
exports.ChatSessionRefreshedNotification = ChatSessionRefreshedNotification;
