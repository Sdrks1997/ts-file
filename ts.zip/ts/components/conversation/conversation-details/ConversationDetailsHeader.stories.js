"use strict";
// Copyright 2021 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const React = __importStar(require("react"));
const react_1 = require("@storybook/react");
const addon_actions_1 = require("@storybook/addon-actions");
const addon_knobs_1 = require("@storybook/addon-knobs");
const getDefaultConversation_1 = require("../../../test-both/helpers/getDefaultConversation");
const i18n_1 = require("../../../../js/modules/i18n");
const messages_json_1 = __importDefault(require("../../../../_locales/en/messages.json"));
const ConversationDetailsHeader_1 = require("./ConversationDetailsHeader");
const i18n = i18n_1.setup('en', messages_json_1.default);
const story = react_1.storiesOf('Components/Conversation/ConversationDetails/ConversationDetailsHeader', module);
const createConversation = () => getDefaultConversation_1.getDefaultConversation({
    id: '',
    type: 'group',
    lastUpdated: 0,
    title: addon_knobs_1.text('conversation title', 'Some Conversation'),
});
const createProps = (overrideProps = {}) => (Object.assign({ conversation: createConversation(), i18n, canEdit: false, startEditing: addon_actions_1.action('startEditing'), memberships: new Array(addon_knobs_1.number('conversation members length', 0)) }, overrideProps));
story.add('Basic', () => {
    const props = createProps();
    return React.createElement(ConversationDetailsHeader_1.ConversationDetailsHeader, Object.assign({}, props));
});
story.add('Editable', () => {
    const props = createProps({ canEdit: true });
    return React.createElement(ConversationDetailsHeader_1.ConversationDetailsHeader, Object.assign({}, props));
});
