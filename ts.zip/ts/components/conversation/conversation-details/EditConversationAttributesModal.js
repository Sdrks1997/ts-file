"use strict";
// Copyright 2021 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EditConversationAttributesModal = void 0;
const react_1 = __importStar(require("react"));
const lodash_1 = require("lodash");
const Modal_1 = require("../../Modal");
const AvatarInput_1 = require("../../AvatarInput");
const Button_1 = require("../../Button");
const Spinner_1 = require("../../Spinner");
const GroupDescriptionInput_1 = require("../../GroupDescriptionInput");
const GroupTitleInput_1 = require("../../GroupTitleInput");
const log = __importStar(require("../../../logging/log"));
const canvasToArrayBuffer_1 = require("../../../util/canvasToArrayBuffer");
const util_1 = require("./util");
const TEMPORARY_AVATAR_VALUE = new ArrayBuffer(0);
const EditConversationAttributesModal = ({ avatarPath: externalAvatarPath, groupDescription: externalGroupDescription = '', i18n, initiallyFocusDescription, makeRequest, onClose, requestState, title: externalTitle, }) => {
    const focusDescriptionRef = react_1.useRef(initiallyFocusDescription);
    const focusDescription = focusDescriptionRef.current;
    const startingTitleRef = react_1.useRef(externalTitle);
    const startingAvatarPathRef = react_1.useRef(externalAvatarPath);
    const [avatar, setAvatar] = react_1.useState(externalAvatarPath ? TEMPORARY_AVATAR_VALUE : undefined);
    const [rawTitle, setRawTitle] = react_1.useState(externalTitle);
    const [rawGroupDescription, setRawGroupDescription] = react_1.useState(externalGroupDescription);
    const [hasAvatarChanged, setHasAvatarChanged] = react_1.useState(false);
    const trimmedTitle = rawTitle.trim();
    const trimmedDescription = rawGroupDescription.trim();
    const focusRef = (el) => {
        if (el) {
            el.focus();
            focusDescriptionRef.current = undefined;
        }
    };
    react_1.useEffect(() => {
        const startingAvatarPath = startingAvatarPathRef.current;
        if (!startingAvatarPath) {
            return lodash_1.noop;
        }
        let shouldCancel = false;
        (async () => {
            try {
                const buffer = await imagePathToArrayBuffer(startingAvatarPath);
                if (shouldCancel) {
                    return;
                }
                setAvatar(buffer);
            }
            catch (err) {
                log.warn(`Failed to convert image URL to array buffer. Error message: ${err && err.message}`);
            }
        })();
        return () => {
            shouldCancel = true;
        };
    }, []);
    const hasChangedExternally = startingAvatarPathRef.current !== externalAvatarPath ||
        startingTitleRef.current !== externalTitle;
    const hasTitleChanged = trimmedTitle !== externalTitle.trim();
    const hasGroupDescriptionChanged = externalGroupDescription.trim() !== trimmedDescription;
    const isRequestActive = requestState === util_1.RequestState.Active;
    const canSubmit = !isRequestActive &&
        (hasChangedExternally ||
            hasTitleChanged ||
            hasAvatarChanged ||
            hasGroupDescriptionChanged) &&
        trimmedTitle.length > 0;
    const onSubmit = event => {
        event.preventDefault();
        const request = {};
        if (hasAvatarChanged) {
            request.avatar = avatar;
        }
        if (hasTitleChanged) {
            request.title = trimmedTitle;
        }
        if (hasGroupDescriptionChanged) {
            request.description = trimmedDescription;
        }
        makeRequest(request);
    };
    return (react_1.default.createElement(Modal_1.Modal, { hasXButton: true, i18n: i18n, onClose: onClose, title: i18n('updateGroupAttributes__title') },
        react_1.default.createElement("form", { onSubmit: onSubmit, className: "module-EditConversationAttributesModal" },
            react_1.default.createElement(AvatarInput_1.AvatarInput, { contextMenuId: "edit conversation attributes avatar input", disabled: isRequestActive, i18n: i18n, onChange: newAvatar => {
                    setAvatar(newAvatar);
                    setHasAvatarChanged(true);
                }, value: avatar, variant: AvatarInput_1.AvatarInputVariant.Dark }),
            react_1.default.createElement(GroupTitleInput_1.GroupTitleInput, { disabled: isRequestActive, i18n: i18n, onChangeValue: setRawTitle, ref: focusDescription === false ? focusRef : undefined, value: rawTitle }),
            react_1.default.createElement(GroupDescriptionInput_1.GroupDescriptionInput, { disabled: isRequestActive, i18n: i18n, onChangeValue: setRawGroupDescription, ref: focusDescription === true ? focusRef : undefined, value: rawGroupDescription }),
            react_1.default.createElement("div", { className: "module-EditConversationAttributesModal__description-warning" }, i18n('EditConversationAttributesModal__description-warning')),
            requestState === util_1.RequestState.InactiveWithError && (react_1.default.createElement("div", { className: "module-EditConversationAttributesModal__error-message" }, i18n('updateGroupAttributes__error-message'))),
            react_1.default.createElement(Modal_1.Modal.ButtonFooter, null,
                react_1.default.createElement(Button_1.Button, { disabled: isRequestActive, onClick: onClose, variant: Button_1.ButtonVariant.Secondary }, i18n('cancel')),
                react_1.default.createElement(Button_1.Button, { type: "submit", variant: Button_1.ButtonVariant.Primary, disabled: !canSubmit }, isRequestActive ? (react_1.default.createElement(Spinner_1.Spinner, { size: "20px", svgSize: "small", direction: "on-avatar" })) : (i18n('save')))))));
};
exports.EditConversationAttributesModal = EditConversationAttributesModal;
async function imagePathToArrayBuffer(src) {
    const image = new Image();
    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d');
    if (!context) {
        throw new Error('imagePathToArrayBuffer: could not get canvas rendering context');
    }
    image.src = src;
    await image.decode();
    canvas.width = image.width;
    canvas.height = image.height;
    context.drawImage(image, 0, 0);
    const result = await canvasToArrayBuffer_1.canvasToArrayBuffer(canvas);
    return result;
}
