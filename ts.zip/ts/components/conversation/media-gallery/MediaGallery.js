"use strict";
// Copyright 2018-2020 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MediaGallery = void 0;
const react_1 = __importDefault(require("react"));
const classnames_1 = __importDefault(require("classnames"));
const moment_1 = __importDefault(require("moment"));
const AttachmentSection_1 = require("./AttachmentSection");
const EmptyState_1 = require("./EmptyState");
const groupMediaItemsByDate_1 = require("./groupMediaItemsByDate");
const missingCaseError_1 = require("../../../util/missingCaseError");
const getMessageTimestamp_1 = require("../../../util/getMessageTimestamp");
const MONTH_FORMAT = 'MMMM YYYY';
const Tab = ({ isSelected, label, onSelect, type, }) => {
    const handleClick = onSelect
        ? () => {
            onSelect({ type });
        }
        : undefined;
    return (
    // Has key events handled elsewhere
    // eslint-disable-next-line jsx-a11y/click-events-have-key-events
    react_1.default.createElement("div", { className: classnames_1.default('module-media-gallery__tab', isSelected ? 'module-media-gallery__tab--active' : null), onClick: handleClick, role: "tab", tabIndex: 0 }, label));
};
class MediaGallery extends react_1.default.Component {
    constructor(props) {
        super(props);
        this.focusRef = react_1.default.createRef();
        this.handleTabSelect = (event) => {
            this.setState({ selectedTab: event.type });
        };
        this.state = {
            selectedTab: 'media',
        };
    }
    componentDidMount() {
        // When this component is created, it's initially not part of the DOM, and then it's
        //   added off-screen and animated in. This ensures that the focus takes.
        setTimeout(() => {
            if (this.focusRef.current) {
                this.focusRef.current.focus();
            }
        });
    }
    render() {
        const { selectedTab } = this.state;
        return (react_1.default.createElement("div", { className: "module-media-gallery", tabIndex: -1, ref: this.focusRef },
            react_1.default.createElement("div", { className: "module-media-gallery__tab-container" },
                react_1.default.createElement(Tab, { label: "Media", type: "media", isSelected: selectedTab === 'media', onSelect: this.handleTabSelect }),
                react_1.default.createElement(Tab, { label: "Documents", type: "documents", isSelected: selectedTab === 'documents', onSelect: this.handleTabSelect })),
            react_1.default.createElement("div", { className: "module-media-gallery__content" }, this.renderSections())));
    }
    renderSections() {
        const { i18n, media, documents, onItemClick } = this.props;
        const { selectedTab } = this.state;
        const mediaItems = selectedTab === 'media' ? media : documents;
        const type = selectedTab;
        if (!mediaItems || mediaItems.length === 0) {
            const label = (() => {
                switch (type) {
                    case 'media':
                        return i18n('mediaEmptyState');
                    case 'documents':
                        return i18n('documentsEmptyState');
                    default:
                        throw missingCaseError_1.missingCaseError(type);
                }
            })();
            return react_1.default.createElement(EmptyState_1.EmptyState, { "data-test": "EmptyState", label: label });
        }
        const now = Date.now();
        const sections = groupMediaItemsByDate_1.groupMediaItemsByDate(now, mediaItems).map(section => {
            const first = section.mediaItems[0];
            const { message } = first;
            const date = moment_1.default(getMessageTimestamp_1.getMessageTimestamp(message));
            const header = section.type === 'yearMonth'
                ? date.format(MONTH_FORMAT)
                : i18n(section.type);
            return (react_1.default.createElement(AttachmentSection_1.AttachmentSection, { key: header, header: header, i18n: i18n, type: type, mediaItems: section.mediaItems, onItemClick: onItemClick }));
        });
        return react_1.default.createElement("div", { className: "module-media-gallery__sections" }, sections);
    }
}
exports.MediaGallery = MediaGallery;
