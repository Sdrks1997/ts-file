"use strict";
// Copyright 2019-2020 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AvatarPopup = void 0;
const React = __importStar(require("react"));
const classnames_1 = __importDefault(require("classnames"));
const Avatar_1 = require("./Avatar");
const hooks_1 = require("../util/hooks");
const AvatarPopup = (props) => {
    const focusRef = React.useRef(null);
    const { i18n, name, profileName, phoneNumber, title, onSetChatColor, onViewPreferences, onViewArchive, style, } = props;
    const shouldShowNumber = Boolean(name || profileName);
    // Note: mechanisms to dismiss this view are all in its host, MainHeader
    // Focus first button after initial render, restore focus on teardown
    hooks_1.useRestoreFocus(focusRef);
    return (React.createElement("div", { style: style, className: "module-avatar-popup" },
        React.createElement("div", { className: "module-avatar-popup__profile" },
            React.createElement(Avatar_1.Avatar, Object.assign({}, props, { size: 52 })),
            React.createElement("div", { className: "module-avatar-popup__profile__text" },
                React.createElement("div", { className: "module-avatar-popup__profile__name" }, profileName || title),
                shouldShowNumber ? (React.createElement("div", { className: "module-avatar-popup__profile__number" }, phoneNumber)) : null)),
        React.createElement("hr", { className: "module-avatar-popup__divider" }),
        React.createElement("button", { type: "button", ref: focusRef, className: "module-avatar-popup__item", onClick: onViewPreferences },
            React.createElement("div", { className: classnames_1.default('module-avatar-popup__item__icon', 'module-avatar-popup__item__icon-settings') }),
            React.createElement("div", { className: "module-avatar-popup__item__text" }, i18n('mainMenuSettings'))),
        React.createElement("button", { type: "button", className: "module-avatar-popup__item", onClick: onSetChatColor },
            React.createElement("div", { className: classnames_1.default('module-avatar-popup__item__icon', 'module-avatar-popup__item__icon-colors') }),
            React.createElement("div", { className: "module-avatar-popup__item__text" }, i18n('avatarMenuChatColors'))),
        React.createElement("button", { type: "button", className: "module-avatar-popup__item", onClick: onViewArchive },
            React.createElement("div", { className: classnames_1.default('module-avatar-popup__item__icon', 'module-avatar-popup__item__icon-archive') }),
            React.createElement("div", { className: "module-avatar-popup__item__text" }, i18n('avatarMenuViewArchive')))));
};
exports.AvatarPopup = AvatarPopup;
