"use strict";
// Copyright 2021 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const react_1 = __importStar(require("react"));
const uuid_1 = require("uuid");
const lodash_1 = require("lodash");
const react_2 = require("@storybook/react");
const i18n_1 = require("../../js/modules/i18n");
const messages_json_1 = __importDefault(require("../../_locales/en/messages.json"));
const AvatarInput_1 = require("./AvatarInput");
const i18n = i18n_1.setup('en', messages_json_1.default);
const story = react_2.storiesOf('Components/AvatarInput', module);
const TEST_IMAGE = new Uint8Array(lodash_1.chunk('89504e470d0a1a0a0000000d4948445200000008000000080103000000fec12cc800000006504c5445ff00ff00ff000c82e9800000001849444154085b633061a8638863a867f8c720c760c12000001a4302f4d81dd9870000000049454e44ae426082', 2).map(bytePair => parseInt(bytePair.join(''), 16))).buffer;
const Wrapper = ({ startValue, variant, }) => {
    const [value, setValue] = react_1.useState(startValue);
    const [objectUrl, setObjectUrl] = react_1.useState();
    react_1.useEffect(() => {
        if (!value) {
            setObjectUrl(undefined);
            return lodash_1.noop;
        }
        const url = URL.createObjectURL(new Blob([value]));
        setObjectUrl(url);
        return () => {
            URL.revokeObjectURL(url);
        };
    }, [value]);
    return (react_1.default.createElement(react_1.default.Fragment, null,
        react_1.default.createElement(AvatarInput_1.AvatarInput, { contextMenuId: uuid_1.v4(), i18n: i18n, value: value, onChange: setValue, variant: variant }),
        react_1.default.createElement("figure", null,
            react_1.default.createElement("figcaption", null, "Processed image (if it exists)"),
            objectUrl && react_1.default.createElement("img", { src: objectUrl, alt: "" }))));
};
story.add('No start state', () => {
    return react_1.default.createElement(Wrapper, { startValue: undefined });
});
story.add('Starting with a value', () => {
    return react_1.default.createElement(Wrapper, { startValue: TEST_IMAGE });
});
story.add('Dark variant', () => {
    return react_1.default.createElement(Wrapper, { startValue: undefined, variant: AvatarInput_1.AvatarInputVariant.Dark });
});
